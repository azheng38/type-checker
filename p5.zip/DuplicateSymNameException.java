public class DuplicateSymNameException extends Exception {
	
}